import dayjs from 'dayjs';

type IdleProps = {
    formData: any;
    company:any;
    drivers:number;
};

export function getIdleDriver({ company, formData, drivers }:IdleProps):number {

    const pricePerDriver = company.overnight_supplement_per_driver;
    console.log('costoPor consultor', pricePerDriver);


    const {startDate , startTime, endDate, endTime} = formData;


    const startDateTime = dayjs(`${startDate}T${startTime}`);
    const endDateTime = dayjs(`${endDate}T${endTime}`);


    const daysDifference = endDateTime.diff(startDateTime, 'day');
    console.log('dias de diferencia ', daysDifference);


    if (daysDifference > 1) {
        const price = Math.ceil(daysDifference * pricePerDriver);

        console.log('price ', price);
        const driverMultiplier = drivers === 0 ? 1 : 2;

        console.log('driverMultiplier ', driverMultiplier);

        return price*driverMultiplier;
    }

    return 0
}   