import dayjs from 'dayjs';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';

dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);


dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);

type NightServiceProps = {
    companySettings: { night_start_time: string; night_end_time: string };
    formData: { startDate: string; startTime: string; endDate: string; endTime: string };
    vehicleDetail: { night_service_surcharge: number };
    totalHoursSegment1: number;
    totalHoursSegment2: number;
};

type NightServiceResponseProps = {
    nightServicesSegment1: number;
    nightServicesSegment2: number;
};

export function getNightServices({
    companySettings,
    formData,
    vehicleDetail,
    totalHoursSegment1,
    totalHoursSegment2,
}: NightServiceProps): NightServiceResponseProps {
    if (!companySettings || !companySettings.night_start_time || !companySettings.night_end_time) {
        console.error('Company settings are missing night start or end times.');
        return { nightServicesSegment1: 0, nightServicesSegment2: 0 };
    }

    const startTimeSegment1 = dayjs(
        `${formData.startDate} ${formData.startTime}`,
        'YYYY-MM-DD HH:mm:ss'
    );
    const endTimeSegment1 = startTimeSegment1.add(totalHoursSegment1, 'hour');

    const startTimeSegment2 = dayjs(
        `${formData.endDate} ${formData.endTime}`,
        'YYYY-MM-DD HH:mm:ss'
    );
    const endTimeSegment2 = startTimeSegment2.add(totalHoursSegment2, 'hour');

    const nightStart = dayjs(
        `${formData.startDate} ${companySettings.night_start_time}`,
        'YYYY-MM-DD HH:mm:ss'
    );
    const nightEnd = dayjs(
        `${formData.startDate} ${companySettings.night_end_time}`,
        'YYYY-MM-DD HH:mm:ss'
    );

    const isNightCrossing = (start: dayjs.Dayjs, end: dayjs.Dayjs): boolean => {
        if (nightStart.isBefore(nightEnd)) {
            return (
                (start.isSameOrAfter(nightStart) && start.isBefore(nightEnd)) ||
                (end.isSameOrAfter(nightStart) && end.isBefore(nightEnd)) ||
                (start.isBefore(nightStart) && end.isAfter(nightEnd))
            );
        }
        else {
            return (
                (start.isSameOrAfter(nightStart) || start.isBefore(nightEnd)) ||
                (end.isSameOrAfter(nightStart) || end.isBefore(nightEnd)) ||
                (start.isBefore(nightStart) && end.isAfter(nightEnd))
            );
        }
    };

    const hasNightServiceSegment1 = isNightCrossing(startTimeSegment1, endTimeSegment1);
    const nightServicesSegment1 = hasNightServiceSegment1
        ? vehicleDetail.night_service_surcharge
        : 0;

    const hasNightServiceSegment2 = isNightCrossing(startTimeSegment2, endTimeSegment2);
    const nightServicesSegment2 = hasNightServiceSegment2
        ? vehicleDetail.night_service_surcharge
        : 0;

    return {
        nightServicesSegment1,
        nightServicesSegment2,
    };
}


