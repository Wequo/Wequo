import {MAX_WORK_HOURS} from "./config"

type ExtraSuplementProps = {
    driverHours: number;
    pricingRules: any;
    distance:number | null;
    vehicleDetail:any;
};

export function getExtraHourSupplement({driverHours, pricingRules, distance, vehicleDetail}:ExtraSuplementProps) {
    if(distance) {
        if (driverHours <= MAX_WORK_HOURS) return 0;

        //Solo aplicamos el costo de horas extra, siempre que el total distance encaje dentro de algun tramo y supere el max_service_hour.
        if (distance < pricingRules.from_km || distance > pricingRules.to_km) return 0

        
        const extraHours = driverHours - MAX_WORK_HOURS;
        return extraHours * vehicleDetail.price_per_km;
    }
 }