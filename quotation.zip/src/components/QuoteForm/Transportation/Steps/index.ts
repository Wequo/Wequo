import Step1 from "./1"
import Step2 from "./2"
import Step3 from "./3"
import Results from "./results"
export { Step1, Step2, Step3, Results};
