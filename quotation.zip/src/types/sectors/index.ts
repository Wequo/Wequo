export enum SectorType {
    Transportation = 'transportation',
}